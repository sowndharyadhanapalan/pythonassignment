from src.calculator_tanh import tanh_calculation
import sys


def main():
    angle = (sys.argv[1])
    res = tanh_calculation.calculate_tanh(angle)
    print(res)