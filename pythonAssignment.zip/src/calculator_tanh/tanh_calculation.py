"""simple calculator"""
import math
import logging

def calculate_tanh(angle):
    """A method to calculate tanh"""
    logging.basicConfig(filename="configfile.log", level=logging.ERROR, format='%(asctime)s:%(levelname)s:%(message)s',
                        filemode='w')
    try:
        angle=float(angle)
        exponential = math.e
        coshx = ((exponential**angle)+(exponential**-angle))
        sinhx = ((exponential**angle)-(exponential**-angle))
        tanhx = sinhx/coshx
        return tanhx
    except ValueError as e:
        logging.error(e.message)
        return "value error(enter a number)"
